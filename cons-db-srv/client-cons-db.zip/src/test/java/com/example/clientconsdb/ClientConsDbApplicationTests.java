package com.example.clientconsdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientConsDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
