package com.example.clientconsdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientConsDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientConsDbApplication.class, args);
	}

}
