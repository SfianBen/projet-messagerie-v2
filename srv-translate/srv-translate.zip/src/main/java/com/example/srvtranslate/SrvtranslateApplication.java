package com.example.srvtranslate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SrvtranslateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SrvtranslateApplication.class, args);
	}

}
