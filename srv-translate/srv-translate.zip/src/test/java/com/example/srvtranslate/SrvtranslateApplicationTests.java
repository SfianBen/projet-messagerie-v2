package com.example.srvtranslate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SrvtranslateApplicationTests {

	@Test
	void contextLoads() {
	}

}
